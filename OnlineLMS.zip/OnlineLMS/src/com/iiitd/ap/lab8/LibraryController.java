/*
 * 
 * Name: Harish Fulara
 * Roll No: 2014143
 * 
 */

package com.iiitd.ap.lab8;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class LibraryController {

	@FXML
	private TableView<Item> table1, table2, table3, table4, table5, table6, table7;

	@FXML
	private TableColumn<Item, String> column1name, column2name, column3name, column4name, column5name, column6name,
			column7name;
	@FXML
	private TableColumn<Item, String> column1ID, column2ID, column3ID, column4ID, column5ID, column6ID, column7ID;

	@FXML
	private Button userlogin, adminlogin, userloginback, adminloginback, userregister, adminregister, continuetomain,
			userloginsubmit, regsubmit, adminloginsubmit, userlogout, adminlogout, userreserve;

	@FXML
	private TextField userid, regname, adminid, usersearchname, usersearchauthor, adminsearchname, adminsearchauthor;

	@FXML
	private PasswordField userpin, adminpin;

	@FXML
	private RadioButton regmale, regfemale, regstudent, regteacher, regother;

	@FXML
	private Text allocatedID, allocatedPin, regmessage, userloginmessage, adminloginmessage;

	BufferedReader reader;
	BufferedWriter writer;
	private static int adminflag = 0, userflag = 0;
	private static String logpin;
	private final ObservableList<Item> itemData1 = FXCollections.observableArrayList();
	private final ObservableList<Item> itemData2 = FXCollections.observableArrayList();
	private final ObservableList<Item> itemData3 = FXCollections.observableArrayList();
	private final ObservableList<Item> itemData4 = FXCollections.observableArrayList();
	private Item my_item;

	@FXML
	void userLoginScreen(ActionEvent event) throws IOException {
		Stage stage = (Stage) userlogin.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemUserLogin.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void adminLoginScreen(ActionEvent event) throws IOException {
		Stage stage = (Stage) adminlogin.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemAdminLogin.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void mainScreenFromUser(ActionEvent event) throws IOException {
		Stage stage = (Stage) userloginback.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemMainScreen.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void mainScreenFromAdmin(ActionEvent event) throws IOException {
		Stage stage = (Stage) adminloginback.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemMainScreen.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void userRegisterScreen(ActionEvent event) throws IOException {
		userflag = 1;
		Stage stage = (Stage) userregister.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemRegister.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void adminRegisterScreen(ActionEvent event) throws IOException {
		adminflag = 1;
		Stage stage = (Stage) adminregister.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemRegister.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void continueToMainScreen(ActionEvent event) throws IOException {
		Stage stage = (Stage) continuetomain.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemMainScreen.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void userLogOut(ActionEvent event) throws IOException {
		Stage stage = (Stage) userlogout.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemMainScreen.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void adminLogOut(ActionEvent event) throws IOException {
		Stage stage = (Stage) adminlogout.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./LibrarySystemMainScreen.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void userTab1Selected(Event event) {
		my_item = null;
	}

	@FXML
	void userTab2Selected(Event event) throws IOException {
		itemData2.removeAll(itemData2);
		String tmp1, tmp2;
		int flag = 0;
		reader = new BufferedReader(new FileReader("./src/UserDatabase/UserDetails.txt"));
		while ((tmp1 = reader.readLine()) != null) {
			tmp2 = reader.readLine();
			if (tmp1.compareTo(logpin) == 0) {
				String[] str = tmp2.split(",");
				for (int i = 3; i < str.length; i++) {
					String[] str1 = str[i].split("-");
					Item item = new Item(str1[1], str1[0]);
					itemData2.add(item);
				}
				flag = 1;
			}
			if (flag == 1) {
				break;
			}
		}
		reader.close();

		table2.setItems(itemData2);
		column2name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
		column2ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
	}

	@FXML
	void userTab3Selected(Event event) throws IOException {
		my_item = null;
		itemData3.removeAll(itemData3);
		String tmp1, tmp2;
		int flag = 0;
		reader = new BufferedReader(new FileReader("./src/UserDatabase/UserDetails.txt"));
		while ((tmp1 = reader.readLine()) != null) {
			tmp2 = reader.readLine();
			if (tmp1.compareTo(logpin) == 0) {
				String[] str = tmp2.split(",");
				for (int i = 3; i < str.length; i++) {
					String[] str1 = str[i].split("-");
					Item item = new Item(str1[1], str1[0]);
					itemData3.add(item);
				}
				flag = 1;
			}
			if (flag == 1) {
				break;
			}
		}
		reader.close();

		table3.setItems(itemData3);
		column3name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
		column3ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
	}

	@FXML
	void adminTab1Selected(Event event) {
		my_item = null;
	}

	@FXML
	void adminTab2Selected(Event event) throws IOException {
		itemData2.removeAll(itemData2);
		String tmp1, tmp2;
		int flag = 0;
		reader = new BufferedReader(new FileReader("./src/AdminDatabase/AdminDetails.txt"));
		while ((tmp1 = reader.readLine()) != null) {
			tmp2 = reader.readLine();
			if (tmp1.compareTo(logpin) == 0) {
				String[] str = tmp2.split(",");
				for (int i = 3; i < str.length; i++) {
					String[] str1 = str[i].split("-");
					Item item = new Item(str1[1], str1[0]);
					itemData2.add(item);
				}
				flag = 1;
			}
			if (flag == 1) {
				break;
			}
		}
		reader.close();

		table5.setItems(itemData2);
		column5name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
		column5ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
	}

	@FXML
	void adminTab3Selected(Event event) throws IOException {
		itemData4.removeAll(itemData4);
		String tmp;
		reader = new BufferedReader(new FileReader("./src/AdminDatabase/AdminDetails.txt"));
		while ((tmp = reader.readLine()) != null) {
			tmp = reader.readLine();
			String[] str = tmp.split(",");
			for (int i = 3; i < str.length; i++) {
				String[] str1 = str[i].split("-");
				Item item = new Item(str1[1], str1[0]);
				itemData4.add(item);
			}
		}
		reader.close();

		reader = new BufferedReader(new FileReader("./src/UserDatabase/UserDetails.txt"));
		while ((tmp = reader.readLine()) != null) {
			tmp = reader.readLine();
			String[] str = tmp.split(",");
			for (int i = 3; i < str.length; i++) {
				String[] str1 = str[i].split("-");
				Item item = new Item(str1[1], str1[0]);
				itemData4.add(item);
			}
		}
		reader.close();

		table6.setItems(itemData4);
		column6name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
		column6ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
	}

	@FXML
	void adminTab4Selected(Event event) throws IOException {
		my_item = null;
		itemData3.removeAll(itemData3);
		String tmp1, tmp2;
		int flag = 0;
		reader = new BufferedReader(new FileReader("./src/AdminDatabase/AdminDetails.txt"));
		while ((tmp1 = reader.readLine()) != null) {
			tmp2 = reader.readLine();
			if (tmp1.compareTo(logpin) == 0) {
				String[] str = tmp2.split(",");
				for (int i = 3; i < str.length; i++) {
					String[] str1 = str[i].split("-");
					Item item = new Item(str1[1], str1[0]);
					itemData3.add(item);
				}
				flag = 1;
			}
			if (flag == 1) {
				break;
			}
		}
		reader.close();

		table7.setItems(itemData3);
		column7name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
		column7ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
	}

	@FXML
	void userLoginSubmit(ActionEvent event) throws IOException {
		userloginmessage.setVisible(false);

		String libID = userid.getText();
		String libPin = userpin.getText();
		String tmp;
		int flag = 0;

		if (libID.compareTo("") == 0 || libPin.compareTo("") == 0) {
			userloginmessage.setVisible(true);
			return;
		}

		reader = new BufferedReader(new FileReader("./src/UserDatabase/UserLogin.txt"));
		while ((tmp = reader.readLine()) != null) {
			String[] str = tmp.split(",");

			if (str[0].compareTo(libID) == 0 && str[1].compareTo(libPin) == 0) {
				userLoggedIn();
				logpin = libPin;
				flag = 1;
				break;
			}
		}

		if (flag == 0) {
			userloginmessage.setVisible(true);
		}
		reader.close();
	}

	@FXML
	void adminLoginSubmit(ActionEvent event) throws IOException {
		adminloginmessage.setVisible(false);

		String libID = adminid.getText();
		String libPin = adminpin.getText();
		String tmp;
		int flag = 0;

		if (libID.compareTo("") == 0 || libPin.compareTo("") == 0) {
			adminloginmessage.setVisible(true);
			return;
		}

		reader = new BufferedReader(new FileReader("./src/AdminDatabase/AdminLogin.txt"));
		while ((tmp = reader.readLine()) != null) {
			String[] str = tmp.split(",");

			if (str[0].compareTo(libID) == 0 && str[1].compareTo(libPin) == 0) {
				adminLoggedIn();
				logpin = libPin;
				flag = 1;
				break;
			}
		}

		if (flag == 0) {
			adminloginmessage.setVisible(true);
		}
		reader.close();
	}

	void userLoggedIn() throws IOException {
		Stage stage = (Stage) userloginsubmit.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./UserAfterLogin.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	void adminLoggedIn() throws IOException {
		Stage stage = (Stage) adminloginsubmit.getScene().getWindow();
		Parent root = FXMLLoader.load(getClass().getResource("./AdminAfterLogin.fxml"));
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	void registrationSubmit(ActionEvent event) throws IOException {
		regmessage.setVisible(false);
		allocatedID.setVisible(false);
		allocatedPin.setVisible(false);

		int flag1 = 0, flag2 = 0, flag3 = 0;
		String name = null;
		String sex = null;
		String profession = null;

		if (regname.getText().compareTo("") != 0) {
			name = regname.getText();
		} else {
			flag1 = 1;
		}

		if (regmale.isSelected() == true) {
			sex = "Male";
		} else if (regfemale.isSelected() == true) {
			sex = "Female";
		} else {
			flag2 = 1;
		}

		if (regstudent.isSelected() == true) {
			profession = "Student";
		} else if (regteacher.isSelected() == true) {
			profession = "Teacher";
		} else if (regother.isSelected() == true) {
			profession = "Other";
		} else {
			flag3 = 1;
		}

		if (flag1 == 1 || flag2 == 1 || flag3 == 1) {
			regmessage.setText("Incomplete details");
			regmessage.setFill(Color.FIREBRICK);
			regmessage.setVisible(true);
		} else {
			regmessage.setText("Submitted Successfully");
			regmessage.setFill(Color.GREEN);
			regmessage.setVisible(true);

			regname.setDisable(true);
			regmale.setDisable(true);
			regfemale.setDisable(true);
			regstudent.setDisable(true);
			regteacher.setDisable(true);
			regother.setDisable(true);
			regsubmit.setDisable(true);

			String ID, Pin;
			Integer tmp, tmpID, tmpPin;

			if (userflag == 1) {
				reader = new BufferedReader(new FileReader("./src/System/ID.txt"));
				tmp = Integer.valueOf(reader.readLine());
				tmpID = tmp;
				tmp++;
				reader.close();
				writer = new BufferedWriter(new FileWriter("./src/System/ID.txt"));
				writer.write(String.valueOf(tmp));
				writer.close();

				reader = new BufferedReader(new FileReader("./src/System/Pin.txt"));
				tmp = Integer.valueOf(reader.readLine());
				tmpPin = tmp;
				tmp++;
				reader.close();
				writer = new BufferedWriter(new FileWriter("./src/System/Pin.txt"));
				writer.write(String.valueOf(tmp));
				writer.close();

				writer = new BufferedWriter(new FileWriter("./src/UserDatabase/UserLogin.txt", true));
				String[] str = name.split(" ");
				ID = "U" + str[0].toLowerCase() + String.valueOf(tmpID);
				Pin = String.valueOf(tmpPin);
				writer.write(ID + "," + Pin + "\n");
				writer.close();

				writer = new BufferedWriter(new FileWriter("./src/UserDatabase/UserDetails.txt", true));
				writer.write(Pin + "\n");
				writer.write(name + "," + sex + "," + profession + "\n");
				writer.close();

				allocatedID.setText(ID);
				allocatedPin.setText(Pin);
				allocatedID.setFill(Color.GREEN);
				allocatedPin.setFill(Color.GREEN);
				allocatedID.setVisible(true);
				allocatedPin.setVisible(true);

				userflag = 0;
			} else if (adminflag == 1) {
				reader = new BufferedReader(new FileReader("./src/System/ID.txt"));
				tmp = Integer.valueOf(reader.readLine());
				tmpID = tmp;
				tmp++;
				reader.close();
				writer = new BufferedWriter(new FileWriter("./src/System/ID.txt"));
				writer.write(String.valueOf(tmp));
				writer.close();

				reader = new BufferedReader(new FileReader("./src/System/Pin.txt"));
				tmp = Integer.valueOf(reader.readLine());
				tmpPin = tmp;
				tmp++;
				reader.close();
				writer = new BufferedWriter(new FileWriter("./src/System/Pin.txt"));
				writer.write(String.valueOf(tmp));
				writer.close();

				writer = new BufferedWriter(new FileWriter("./src/AdminDatabase/AdminLogin.txt", true));
				String[] str = name.split(" ");
				ID = "A" + str[0].toLowerCase() + String.valueOf(tmpID);
				Pin = String.valueOf(tmpPin);
				writer.write(ID + "," + Pin + "\n");
				writer.close();

				writer = new BufferedWriter(new FileWriter("./src/AdminDatabase/AdminDetails.txt", true));
				writer.write(Pin + "\n");
				writer.write(name + "," + sex + "," + profession + "\n");
				writer.close();

				allocatedID.setText(ID);
				allocatedPin.setText(Pin);
				allocatedID.setFill(Color.GREEN);
				allocatedPin.setFill(Color.GREEN);
				allocatedID.setVisible(true);
				allocatedPin.setVisible(true);

				adminflag = 0;
			}
		}
	}

	@FXML
	void userSearchSubmit(ActionEvent event) throws IOException {
		itemData1.removeAll(itemData1);
		int flag1 = 0, flag2 = 0;
		String name = null;
		String author = null;
		String tmp, tmp1;

		if (usersearchname.getText().compareTo("") != 0) {
			flag1 = 1;
			name = usersearchname.getText();
		}
		if (usersearchauthor.getText().compareTo("") != 0) {
			flag2 = 1;
			author = usersearchauthor.getText();
		}

		if (flag1 == 0 && flag2 == 0) {
			table1.setItems(itemData1);
			return;
		}

		if (flag1 == 1) {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			while ((tmp = reader.readLine()) != null) {
				tmp1 = reader.readLine();
				String[] str = tmp.split(",");
				if (tmp1.compareToIgnoreCase("Y") == 0 && str[1].compareToIgnoreCase(name) == 0) {
					if (flag2 == 1) {
						if (str[2].compareToIgnoreCase(author) == 0) {
							Item item = new Item(str[1], str[0]);
							itemData1.add(item);
						}
					} else {
						Item item = new Item(str[1], str[0]);
						itemData1.add(item);
					}
				}
			}
			reader.close();

			table1.setItems(itemData1);
			column1name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
			column1ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
		} else if (flag2 == 1) {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			while ((tmp = reader.readLine()) != null) {
				tmp1 = reader.readLine();
				String[] str = tmp.split(",");
				if (tmp1.compareToIgnoreCase("Y") == 0 && str[2].compareToIgnoreCase(author) == 0) {
					Item item = new Item(str[1], str[0]);
					itemData1.add(item);
				}
			}
			reader.close();

			table1.setItems(itemData1);
			column1name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
			column1ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
		}
	}

	@FXML
	void adminSearchSubmit(ActionEvent event) throws IOException {
		itemData1.removeAll(itemData1);
		int flag1 = 0, flag2 = 0;
		String name = null;
		String author = null;
		String tmp, tmp1;

		if (adminsearchname.getText().compareTo("") != 0) {
			flag1 = 1;
			name = adminsearchname.getText();
		}
		if (adminsearchauthor.getText().compareTo("") != 0) {
			flag2 = 1;
			author = adminsearchauthor.getText();
		}

		if (flag1 == 0 && flag2 == 0) {
			table4.setItems(itemData1);
			return;
		}

		if (flag1 == 1) {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			while ((tmp = reader.readLine()) != null) {
				tmp1 = reader.readLine();
				String[] str = tmp.split(",");
				if (tmp1.compareToIgnoreCase("Y") == 0 && str[1].compareToIgnoreCase(name) == 0) {
					if (flag2 == 1) {
						if (str[2].compareToIgnoreCase(author) == 0) {
							Item item = new Item(str[1], str[0]);
							itemData1.add(item);
						}
					} else {
						Item item = new Item(str[1], str[0]);
						itemData1.add(item);
					}
				}
			}
			reader.close();

			table4.setItems(itemData1);
			column4name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
			column4ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
		} else if (flag2 == 1) {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			while ((tmp = reader.readLine()) != null) {
				tmp1 = reader.readLine();
				String[] str = tmp.split(",");
				if (tmp1.compareToIgnoreCase("Y") == 0 && str[2].compareToIgnoreCase(author) == 0) {
					Item item = new Item(str[1], str[0]);
					itemData1.add(item);
				}
			}
			reader.close();

			table4.setItems(itemData1);
			column4name.setCellValueFactory(cellData -> cellData.getValue().firstColumnProperty());
			column4ID.setCellValueFactory(cellData -> cellData.getValue().secondColumnProperty());
		}
	}

	@FXML
	public void userReserve(ActionEvent evnt) {
		if (my_item == null) {
			return;
		}
		String itemID = my_item.getID();
		String itemName = my_item.getName();
		String tmp1, tmp2;
		try {
			reader = new BufferedReader(new FileReader("./src/UserDatabase/UserDetails.txt"));
			writer = new BufferedWriter(new FileWriter("./src/UserDatabase/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				if (tmp1.compareTo(logpin) == 0) {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "," + itemID + "-" + itemName + "\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		File file = new File("./src/UserDatabase/UserDetails.txt");
		file.delete();

		File file1 = new File("./src/UserDatabase/temp.txt");
		File file2 = new File("./src/UserDatabase/UserDetails.txt");
		file1.renameTo(file2);

		try {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			writer = new BufferedWriter(new FileWriter("./src/System/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				String[] str = tmp1.split(",");

				if (str[0].compareTo(itemID) == 0) {
					writer.write(tmp1 + "\n");
					writer.write("N" + "\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		file = new File("./src/System/Catalog.txt");
		file.delete();

		file1 = new File("./src/System/temp.txt");
		file2 = new File("./src/System/Catalog.txt");

		file1.renameTo(file2);

		try {
			userSearchSubmit(evnt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		my_item = null;
	}

	@FXML
	public void adminReserve(ActionEvent evnt) {
		if (my_item == null) {
			return;
		}
		String itemName = my_item.getName();
		String itemID = my_item.getID();
		String tmp1, tmp2;

		try {
			reader = new BufferedReader(new FileReader("./src/AdminDatabase/AdminDetails.txt"));
			writer = new BufferedWriter(new FileWriter("./src/AdminDatabase/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				if (tmp1.compareTo(logpin) == 0) {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "," + itemID + "-" + itemName + "\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File file = new File("./src/AdminDatabase/AdminDetails.txt");
		file.delete();

		File file1 = new File("./src/AdminDatabase/temp.txt");
		File file2 = new File("./src/AdminDatabase/AdminDetails.txt");
		file1.renameTo(file2);

		try {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			writer = new BufferedWriter(new FileWriter("./src/System/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				String[] str = tmp1.split(",");

				if (str[0].compareTo(itemID) == 0) {
					writer.write(tmp1 + "\n");
					writer.write("N" + "\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		file = new File("./src/System/Catalog.txt");
		file.delete();

		file1 = new File("./src/System/temp.txt");
		file2 = new File("./src/System/Catalog.txt");

		file1.renameTo(file2);

		try {
			adminSearchSubmit(evnt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		my_item = null;
	}

	@FXML
	public void userRelease(ActionEvent evnt) {
		if (my_item == null) {
			return;
		}
		String itemID = my_item.getID();
		String tmp1, tmp2;
		try {
			reader = new BufferedReader(new FileReader("./src/UserDatabase/UserDetails.txt"));
			writer = new BufferedWriter(new FileWriter("./src/UserDatabase/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				if (tmp1.compareTo(logpin) == 0) {
					writer.write(tmp1 + "\n");
					String[] str = tmp2.split(",");
					writer.write(str[0] + "," + str[1] + "," + str[2]);
					for (int i = 3; i < str.length; i++) {
						String[] str1 = str[i].split("-");
						if (str1[0].compareTo(itemID) != 0) {
							writer.write("," + str[i]);
						}
					}
					writer.write("\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File file = new File("./src/UserDatabase/UserDetails.txt");
		file.delete();

		File file1 = new File("./src/UserDatabase/temp.txt");
		File file2 = new File("./src/UserDatabase/UserDetails.txt");
		file1.renameTo(file2);

		try {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			writer = new BufferedWriter(new FileWriter("./src/System/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				String[] str = tmp1.split(",");

				if (str[0].compareTo(itemID) == 0) {
					writer.write(tmp1 + "\n");
					writer.write("Y" + "\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		file = new File("./src/System/Catalog.txt");
		file.delete();

		file1 = new File("./src/System/temp.txt");
		file2 = new File("./src/System/Catalog.txt");

		file1.renameTo(file2);

		try {
			userSearchSubmit(evnt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			userTab3Selected((Event) evnt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		my_item = null;
	}

	@FXML
	public void adminRelease(ActionEvent evnt) {
		if (my_item == null) {
			return;
		}
		String itemID = my_item.getID();
		String tmp1, tmp2;
		try {
			reader = new BufferedReader(new FileReader("./src/AdminDatabase/AdminDetails.txt"));
			writer = new BufferedWriter(new FileWriter("./src/AdminDatabase/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				if (tmp1.compareTo(logpin) == 0) {
					writer.write(tmp1 + "\n");
					String[] str = tmp2.split(",");
					writer.write(str[0] + "," + str[1] + "," + str[2]);
					for (int i = 3; i < str.length; i++) {
						String[] str1 = str[i].split("-");
						if (str1[0].compareTo(itemID) != 0) {
							writer.write("," + str[i]);
						}
					}
					writer.write("\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		File file = new File("./src/AdminDatabase/AdminDetails.txt");
		file.delete();

		File file1 = new File("./src/AdminDatabase/temp.txt");
		File file2 = new File("./src/AdminDatabase/AdminDetails.txt");
		file1.renameTo(file2);

		try {
			reader = new BufferedReader(new FileReader("./src/System/Catalog.txt"));
			writer = new BufferedWriter(new FileWriter("./src/System/temp.txt"));
			while ((tmp1 = reader.readLine()) != null) {
				tmp2 = reader.readLine();
				String[] str = tmp1.split(",");

				if (str[0].compareTo(itemID) == 0) {
					writer.write(tmp1 + "\n");
					writer.write("Y" + "\n");
				} else {
					writer.write(tmp1 + "\n");
					writer.write(tmp2 + "\n");
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			writer.close();
			reader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		file = new File("./src/System/Catalog.txt");
		file.delete();

		file1 = new File("./src/System/temp.txt");
		file2 = new File("./src/System/Catalog.txt");

		file1.renameTo(file2);

		try {
			adminSearchSubmit(evnt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			adminTab4Selected((Event) evnt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		my_item = null;
	}

	@FXML
	public void getRow1(MouseEvent event) {
		my_item = table1.getSelectionModel().getSelectedItem();
	}

	@FXML
	public void getRow2(MouseEvent event) {
		my_item = table3.getSelectionModel().getSelectedItem();
	}

	@FXML
	public void getRow3(MouseEvent event) {
		my_item = table4.getSelectionModel().getSelectedItem();
	}

	@FXML
	public void getRow4(MouseEvent event) {
		my_item = table7.getSelectionModel().getSelectedItem();
	}

}
