/*
 * 
 * Name: Harish Fulara
 * Roll No: 2014143
 * 
 */

package com.iiitd.ap.lab8;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Item {

	private SimpleStringProperty name;
    private SimpleStringProperty ID;
    
    Item(String name,String ID)
    {
    	this.name = new SimpleStringProperty(name);
        this.ID = new SimpleStringProperty(ID);
    }

	public String getName() {
		return name.get();
	}

	public void setName(String value) {
		name.set(value);;
	}

	public String getID() {
		return ID.get();
	}

	public void setID(String value) {
		ID.set(value);;
	}
	
	public StringProperty firstColumnProperty()
    {
        return name;
    }
    public StringProperty secondColumnProperty()
    {
        return ID;
    }
}
